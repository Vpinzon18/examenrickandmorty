import Badge from 'react-bootstrap/Badge';

function Info() {
  return (
    <div>
      <h1>
        Victor Andres Pinzon Satizabal Ficha  2429500 <Badge bg="secondary"></Badge>
      </h1>
      
      <div>
        <h2>
        PERSONAJES <Badge bg="secondary"></Badge>
      </h2>
      </div>
      
      
      

    </div>
  );
}

export default Info;